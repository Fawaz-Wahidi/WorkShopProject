package com.example.onlinecoursese__learningapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class LessonAdapter extends RecyclerView.Adapter<LessonAdapter.LessonViewHolder> {

    private Lesson[] lessons;
    private OnLessonClickListener onLessonClickListener;

    public LessonAdapter(Lesson[] lessons, OnLessonClickListener listener) {
        this.lessons = lessons;
        this.onLessonClickListener = listener;
    }

    @NonNull
    @Override
    public LessonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lesson_item, parent, false);
        return new LessonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LessonViewHolder holder, int position) {
        Lesson lesson = lessons[position];
        holder.lessonTitle.setText(lesson.getTitle());

        holder.itemView.setOnClickListener(v -> onLessonClickListener.onLessonClick(lesson.getVideoUrl()));
    }

    @Override
    public int getItemCount() {
        return lessons.length;
    }

    public static class LessonViewHolder extends RecyclerView.ViewHolder {
        TextView lessonTitle;

        public LessonViewHolder(@NonNull View itemView) {
            super(itemView);
            lessonTitle = itemView.findViewById(R.id.lesson_title);
        }
    }

    public interface OnLessonClickListener {
        void onLessonClick(String videoUrl);
    }
}
