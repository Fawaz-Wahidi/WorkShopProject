package com.example.onlinecoursese__learningapp;

public class Lesson {

    private final String title;
    private final String duration;
    private final boolean isUnlocked;

    public Lesson(String title, String duration) {
        this.title = title;
        this.duration = duration;
        isUnlocked = false;
    }



    public String getTitle() {
        return title;
    }

    public String getDuration() {
        return duration;
    }

    public boolean isUnlocked() {
        return isUnlocked;
    }


    public String getVideoUrl() {
        return  getVideoUrl();
    }
}
