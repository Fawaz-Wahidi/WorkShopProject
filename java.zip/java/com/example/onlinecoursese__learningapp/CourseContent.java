package com.example.onlinecoursese__learningapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.onlinecoursese__learningapp.RoomDataBase.Course;
import com.example.onlinecoursese__learningapp.RoomDataBase.MyViewModel;
import com.example.onlinecoursese__learningapp.databinding.ActivityCourseContentBinding;

public class CourseContent extends AppCompatActivity {

    private ActivityCourseContentBinding binding;
    private MyViewModel myViewModel;
    private Course course;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCourseContentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        myViewModel = new ViewModelProvider(this).get(MyViewModel.class);

        // Get Course ID from Intent
        int courseId = getIntent().getIntExtra("courseId", -1);

        if (courseId != -1) {
            myViewModel.getAllCourses().observe(this, courses -> {
                for (Course course : courses) {
                    if (course.getId() == courseId) {
                        this.course = course;
                        displayCourseDetails(course);
                    }
                }
            });
        }

        // Set up RecyclerView for lessons
        setupRecyclerView();
    }

    private void displayCourseDetails(Course course) {
        binding.courseTitle.setText(course.getTitle());
        binding.courseDescription.setText(course.getDescription());
        binding.courseInstructor.setText(course.getInstructor());
    }

    private void setupRecyclerView() {
        // Sample data for lessons
        Lesson[] lessons = {
                new Lesson("Lesson 1: Introduction to Business", "https://youtu.be/hgQMyNAIEcU?si=AeP7K71ePsPVtUqs"),
                new Lesson("Lesson 2: Advanced Business Strategies", "https://youtu.be/mvDs2xF85ZI?si=jXixISLZN2qVfibY"),
                new Lesson("Lesson 3: Marketing Fundamentals", "https://youtu.be/OKUVmmST6Mo?si=OnLsVa2uyK2_87Qj"),
                new Lesson("Lesson 4: Financial Management", "https://youtu.be/OKUVmmST6Mo?si=OnLsVa2uyK2_87Qj"),
                new Lesson("Lesson 5: Business Ethics", "https://youtu.be/OKUVmmST6Mo?si=OnLsVa2uyK2_87Qj")
        };

        LessonAdapter lessonAdapter = new LessonAdapter(lessons, new LessonAdapter.OnLessonClickListener() {
            @Override
            public void onLessonClick(String videoUrl) {
                // Open YouTube when a lesson is clicked (Only for the first 3 lessons)
                if (videoUrl != null) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl));
                    startActivity(intent);
                }
            }
        });

        binding.lessonsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.lessonsRecyclerView.setAdapter(lessonAdapter);
    }
}
