package com.example.onlinecoursese__learningapp.RoomDataBase;

public class dataConverter extends Enrollment {

    public dataConverter(int id, int userId, int courseId) {
        super(id, userId, courseId);
    }
}
